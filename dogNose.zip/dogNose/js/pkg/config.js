var config = {
	publicUrl: "http://api.1680210.com/", //线上正式环境
	backUrl: "http://webapp.1680210.com/kai-bms/", //线上正式环境
	ifdebug: false, //当为true的时候是调试模式
	togo:{
		bd:"https://www.baidu.com/s?wd=",
		ss:"",
		by:"",
	}
}
